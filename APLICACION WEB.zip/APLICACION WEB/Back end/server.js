require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Configuración de la base de datos
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'BD_ColegioGuevara',
});

// Conexión a la base de datos
db.connect((err) => {
    if (err) {
        console.error('Error al conectar a la base de datos:', err);
        process.exit(1);
    }
    console.log('Conectado a la base de datos.');

    // Borrar todos los registros de la tabla Administradores al iniciar el servidor
    db.query('TRUNCATE TABLE Administradores', (err) => {
        if (err) {
            console.error('Error al truncar la tabla Administradores:', err);
        } else {
            console.log('Tabla Administradores vaciada correctamente al iniciar el servidor.');
        }
    });
});

// Configuración de nodemailer
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
    tls: {
        rejectUnauthorized: false
    }
});


// Servir archivos estáticos
app.use(express.static(path.join(__dirname, '../Front end')));

// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../Front end/index.html'));
});

// Generar contraseña aleatoria
const generatePassword = () => {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+';
    return Array.from({ length: 12 }, () =>
        charset.charAt(Math.floor(Math.random() * charset.length))
    ).join('');
};

// Ruta para crear usuario
app.post('/crear-usuario', async (req, res) => {
    const { dni, nombre, apellido, correo, rol, adminKey } = req.body;

    try {
        // Validar la clave de acceso para ambos roles (Administrador y Alumnado)
        if ((rol === 'Administrador' || rol === 'Alumnado') && adminKey !== 'Mosconi661') {
            return res.status(403).send('Clave incorrecta para registrar Alumnado o Administrador.');
        }

        const randomPassword = generatePassword();
        const hashedPassword = await bcrypt.hash(randomPassword, 10);

        let query, values;

        if (rol === 'Estudiante') {
            query = `INSERT INTO Estudiantes (dni, nombre, apellido, correo, contrasena, id_curso) VALUES (?, ?, ?, ?, ?, 1)`;
            values = [dni, nombre, apellido, correo, hashedPassword];
        } else if (rol === 'Alumnado') {
            query = `INSERT INTO Alumnado (dni, nombre, apellido, correo, contrasena) VALUES (?, ?, ?, ?, ?)`;
            values = [dni, nombre, apellido, correo, hashedPassword];
        } else if (rol === 'Administrador') {
            query = `INSERT INTO Administradores (dni, nombre, apellido, correo, contrasena) VALUES (?, ?, ?, ?, ?)`;
            values = [dni, nombre, apellido, correo, hashedPassword];
        } else {
            return res.status(400).send('Rol inválido.');
        }

        db.query(query, values, (err) => {
            if (err) {
                console.error('Error al registrar usuario:', err);
                return res.status(500).send('Error al registrar usuario.');
            }

            const mailOptions = {
                from: process.env.EMAIL_USER,
                to: correo,
                subject: 'Registro Exitoso',
                text: `Hola ${nombre},\n\nTu usuario ha sido registrado correctamente.\nUsuario: ${dni}\nContraseña: ${randomPassword}\nRol: ${rol}\n\n¡Gracias por registrarte!`,
            };

            transporter.sendMail(mailOptions, (error) => {
                if (error) {
                    console.error('Error al enviar correo:', error);
                    return res.status(500).send('Usuario registrado, pero no se pudo enviar el correo.');
                }

                res.send('Usuario registrado correctamente. Correo enviado.');
            });
        });
    } catch (error) {
        console.error('Error en el proceso de registro:', error);
        res.status(500).send('Error en el servidor.');
    }
});


// Ruta para inicio de sesión
app.post('/login', (req, res) => {
    const { usuario, contrasena, quien } = req.body;

    let query;

    if (quien === 'Estudiante') {
        query = 'SELECT * FROM Estudiantes WHERE dni = ?';
    } else if (quien === 'Alumnado') {
        query = 'SELECT * FROM Alumnado WHERE dni = ?';
    } else if (quien === 'Administrador') {
        query = 'SELECT * FROM Administradores WHERE dni = ?';
    } else {
        return res.status(400).send('Rol inválido.');
    }

    db.query(query, [usuario], (err, results) => {
        if (err) {
            console.error('Error al buscar usuario:', err);
            return res.status(500).send('Error en el servidor.');
        }

        if (results.length === 0) {
            return res.status(400).send('Usuario no encontrado.');
        }

        const user = results[0];
        bcrypt.compare(contrasena, user.contrasena, (err, isMatch) => {
            if (err) {
                console.error('Error al comparar contraseñas:', err);
                return res.status(500).send('Error en el servidor.');
            }

            if (!isMatch) {
                return res.status(400).send('Contraseña incorrecta.');
            }

            if (quien === 'Estudiante') {
                res.status(200).send('/planillaAlum.html');
            } else if (quien === 'Alumnado') {
                res.status(200).send('/planillaAlumnado.html');
            } else if (quien === 'Administrador') {
                res.status(200).send('/planillaAdmi.html');
            }
        });
    });
});



app.post('/recuperar-contrasena', async (req, res) => {
    const { dni } = req.body;

    const query = `
        SELECT 'Estudiantes' AS tabla, nombre, correo FROM Estudiantes WHERE dni = ?
        UNION
        SELECT 'Administradores' AS tabla, nombre, correo FROM Administradores WHERE dni = ?
    `;

    db.query(query, [dni, dni], async (err, results) => {
        if (err) {
            console.error('Error al buscar usuario:', err);
            return res.status(500).send('Error en el servidor.');
        }

        if (results.length === 0) {
            return res.status(404).send('DNI no encontrado.');
        }

        const user = results[0];

        // Verificar si el usuario tiene correo registrado
        if (!user.correo) {
            return res.status(400).send('No hay correo registrado para este DNI.');
        }

        const nuevaContrasena = generatePasswordRecovery();
        const hashedPassword = await bcrypt.hash(nuevaContrasena, 10);

        // Ejecuta el UPDATE en la tabla correspondiente
        const updateQuery =
            user.tabla === 'Estudiantes'
                ? 'UPDATE Estudiantes SET contrasena = ? WHERE dni = ?'
                : 'UPDATE Administradores SET contrasena = ? WHERE dni = ?';

        db.query(updateQuery, [hashedPassword, dni], (err) => {
            if (err) {
                console.error('Error al actualizar contraseña:', err);
                return res.status(500).send('Error al actualizar contraseña.');
            }

            // Configura y envía el correo
            const mailOptions = {
                from: process.env.EMAIL_USER,
                to: user.correo,
                subject: 'Recuperación de Contraseña',
                text: `Hola ${user.nombre},\n\nTu nueva contraseña temporal es: ${nuevaContrasena}\n\nPor favor, cámbiala después de iniciar sesión.`,
            };

            transporter.sendMail(mailOptions, (error) => {
                if (error) {
                    console.error('Error al enviar correo:', error);
                    return res.status(500).send('No se pudo enviar el correo.');
                }

                res.send('Nueva contraseña enviada por correo.');
            });
        });
    });
});


// Función para generar una contraseña aleatoria
const generatePasswordRecovery = () => {
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return Array.from({ length: 12 }, () =>
        charset.charAt(Math.floor(Math.random() * charset.length))
    ).join('');
};




// Ruta para cargar notas
app.post('/cargar-notas', (req, res) => {
    const { dni_estudiante, notas } = req.body;

    if (!dni_estudiante) {
        return res.status(400).send('DNI del estudiante no proporcionado.');
    }

    if (!notas || notas.length === 0) {
        return res.status(400).send('No se enviaron notas.');
    }

    const query = `
        INSERT INTO Notas (dni_estudiante, materia, nota1, nota2, nota3, nota4, cuatrimestre1, cuatrimestre2, nota_final)
        VALUES ?
        ON DUPLICATE KEY UPDATE
            nota1 = VALUES(nota1),
            nota2 = VALUES(nota2),
            nota3 = VALUES(nota3),
            nota4 = VALUES(nota4),
            cuatrimestre1 = VALUES(cuatrimestre1),
            cuatrimestre2 = VALUES(cuatrimestre2),
            nota_final = VALUES(nota_final)
    `;

    const values = notas.map(nota => [
        dni_estudiante,
        nota.materia,
        nota.nota1 || 0,
        nota.nota2 || 0,
        nota.nota3 || 0,
        nota.nota4 || 0,
        nota.cuatrimestre1 || 0,
        nota.cuatrimestre2 || 0,
        nota.nota_final || 0,
    ]);

    db.query(query, [values], (err) => {
        if (err) {
            console.error('Error al cargar notas:', err);
            return res.status(500).send('Error al cargar notas.');
        }

        res.send('Notas cargadas correctamente.');
    });
});

// Ruta para obtener notas
app.get('/obtener-notas/:dni', (req, res) => {
    const { dni } = req.params;

    const query = `
        SELECT
            materia,
            nota1,
            nota2,
            nota3,
            nota4,
            cuatrimestre1,
            cuatrimestre2,
            nota_final
        FROM Notas
        WHERE dni_estudiante = ?
    `;

    db.query(query, [dni], (err, results) => {
        if (err) {
            console.error('Error al consultar notas:', err);
            return res.status(500).json({ error: 'Error al consultar las notas.' });
        }

        if (results.length === 0) {
            return res.status(404).json({ error: 'No se encontraron notas para este estudiante.' });
        }

        res.json(results);
    });
});

// Ruta 404
app.use((req, res) => {
    res.status(404).send('Página no encontrada.');
});

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
