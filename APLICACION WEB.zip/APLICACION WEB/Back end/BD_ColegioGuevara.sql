CREATE DATABASE IF NOT EXISTS bd_colegioguevara;
USE bd_colegioguevara;

-- Tabla de Cursos
CREATE TABLE IF NOT EXISTS Cursos (
    id_curso INT AUTO_INCREMENT PRIMARY KEY,
    nombre_curso VARCHAR(20) NOT NULL
);

-- Tabla de Materias
CREATE TABLE IF NOT EXISTS Materias (
    id_materia INT AUTO_INCREMENT PRIMARY KEY,
    nombre_materia VARCHAR(50) NOT NULL,
    id_curso INT NOT NULL,
    FOREIGN KEY (id_curso) REFERENCES Cursos(id_curso)
);

-- Tabla de Administradores
CREATE TABLE IF NOT EXISTS Administradores (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    dni VARCHAR(15) UNIQUE NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de Estudiantes
CREATE TABLE IF NOT EXISTS Estudiantes (
    dni VARCHAR(15) PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    correo VARCHAR(100),
    contrasena VARCHAR(255) NOT NULL,
    fecha_nacimiento DATE,
    id_curso INT NOT NULL,
    FOREIGN KEY (id_curso) REFERENCES Cursos(id_curso)
);

-- Tabla de Calificaciones
CREATE TABLE IF NOT EXISTS Calificaciones (
    id_calificacion INT AUTO_INCREMENT PRIMARY KEY,
    dni_estudiante VARCHAR(15) NOT NULL,
    id_materia INT NOT NULL,
    calificacion DECIMAL(5, 2),
    fecha_calificacion DATE,
    tipo_calificacion VARCHAR(50),
    FOREIGN KEY (dni_estudiante) REFERENCES Estudiantes(dni),
    FOREIGN KEY (id_materia) REFERENCES Materias(id_materia)
);

-- Tabla de Notas
CREATE TABLE IF NOT EXISTS Notas (
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    dni_estudiante TEXT NOT NULL,
    materia TEXT NOT NULL,
    nota1 REAL,
    nota2 REAL,
    nota3 REAL,
    nota4 REAL,
    cuatrimestre1 REAL,
    cuatrimestre2 REAL,
    nota_final REAL,
    UNIQUE(dni_estudiante, materia),
    FOREIGN KEY (dni_estudiante) REFERENCES Estudiantes(dni)
);




-- Insertar datos iniciales
INSERT INTO Cursos (nombre_curso) VALUES ('1ro 1ra'), ('2do 1ra');
INSERT INTO Materias (nombre_materia, id_curso) VALUES 
('Matemáticas', 1), 
('Diseño Multimedial', 1), 
('Inglés', 1), 
('Programación', 2),
('Electricidad', 2), 
('Lenguas', 1), 
('Redes', 2);

INSERT INTO Administradores (dni, nombre, apellido, correo, contrasena)
VALUES ('12345678', 'Carlos', 'González', 'carlos.gonzalez@admin.com', 'contraseña_admin_encriptada');

INSERT INTO Estudiantes (dni, nombre, apellido, correo, contrasena, id_curso)
VALUES ('98765432', 'Juan', 'Pérez', 'juan.perez@gmail.com', 'contrasena123', 1);

INSERT INTO Calificaciones (dni_estudiante, id_materia, calificacion, fecha_calificacion, tipo_calificacion)
VALUES 
('98765432', 1, 8.5, '2024-11-01', '1ra Nota Parcial'),
('98765432', 1, 7.0, '2024-11-10', '2da Nota Parcial'),
('98765432', 1, 9.0, '2024-11-15', '1er Cuatrimestre'),
('98765432', 1, 8.5, '2024-11-20', '2do Cuatrimestre'),
('98765432', 1, 8.0, '2024-11-25', 'Nota Final');

-- Insertar ejemplo de Notas con las nuevas columnas
INSERT INTO Notas (dni_estudiante, materia, nota1, nota2, nota3, nota4, cuatrimestre1, cuatrimestre2, nota_final)
VALUES 
('98765432', 'Matemáticas', 8.5, 7.0, 8.0, 9.0, 7.75, 8.5, 8.13),
('98765432', 'Diseño Multimedial', 9.0, 8.0, 9.0, 9.0, 8.5, 9.0, 8.75),
('98765432', 'Inglés', 8.0, 9.0, 8.5, 8.0, 8.5, 8.0, 8.25),
('98765432', 'Programación', 7.0, 7.0, 7.0, 8.0, 7.0, 8.0, 7.5),
('98765432', 'Electricidad', 9.0, 9.0, 8.0, 9.0, 9.0, 9.0, 9.0),
('98765432', 'Lenguas', 8.0, 7.0, 7.0, 8.0, 7.5, 8.0, 7.75),
('98765432', 'Redes', 9.0, 8.0, 8.0, 9.0, 8.5, 9.0, 8.75);